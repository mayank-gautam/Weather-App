package com.mayank.gautam99.weatherapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Date;
import java.text.DateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private EditText eCity;
    private TextView tCountry;
    private TextView tCity;
    private TextView tTemperature;
    private TextView tLatitude;
    private TextView tLongitude;
    private TextView tHumidity;
    private TextView tPressure;
    private TextView tWindSpeed;
    private TextView tDescription;
    private ImageView weatherImage;
    private TextView tCurrTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        importAllElement();
        hideKeyboard();

    }

    private void importAllElement() {
        eCity    = findViewById(R.id.editTextCity);
        tCountry = findViewById(R.id.countryTextView);
        tCity    = findViewById(R.id.City);
        tTemperature = findViewById(R.id.temprature);
        tLatitude = findViewById(R.id.latitudeValue);
        tLongitude = findViewById(R.id.longitudeValue);
        tHumidity = findViewById(R.id.humidityValue);
        tPressure = findViewById(R.id.pressureValue);
        tWindSpeed = findViewById(R.id.windSpeedValue);
        tDescription = findViewById(R.id.description);
        weatherImage = findViewById(R.id.weatherImage);
        tCurrTime = findViewById(R.id.currTime);
    }

    private void LoadWeather() {

        String url = "http://api.openweathermap.org/data/2.5/weather?q="+eCity.getText().toString()+"&appid=9c03d1da905127a75456a73f64221e50";

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onResponse(JSONObject response) {
                try {

                    JSONArray weatherArray = response.getJSONArray("weather");
                    JSONObject jsonObject = weatherArray.getJSONObject(0);
                    tDescription.setText(jsonObject.getString("main"));
                    String icon = jsonObject.getString("icon");
                    Glide.with(getApplicationContext()).load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(weatherImage);
                    weatherImage.setVisibility(View.VISIBLE);

                    jsonObject = response.getJSONObject("sys");
                    tCountry.setText(jsonObject.getString("country"));


                    tCity.setText(response.getString("name"));

                    jsonObject = response.getJSONObject("main");
                    String tempValue = (int) (jsonObject.getDouble("temp") - 273.15)+"°C";
                    tTemperature.setText(tempValue);
                    String humidity = jsonObject.getString("humidity")+"  %";
                    tHumidity.setText(humidity);
                    String pressure = jsonObject.getString("pressure")+"  hPa";
                    tPressure.setText(pressure);

                    jsonObject = response.getJSONObject("wind");
                    String windSpeed = jsonObject.getString("speed")+"  km/h";
                    tWindSpeed.setText(windSpeed);

                    jsonObject = response.getJSONObject("coord");
                    String latitude = jsonObject.getString("lat")+"°  N";
                    tLatitude.setText(latitude);
                    String longitude = jsonObject.getString("lon")+"°  E";
                    tLongitude.setText(longitude);



                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "City Name Empty/Invalid", Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(jsonObjectRequest);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void searchButton(View view) {
        if(isInternetConnected()) {
            LoadWeather();
            Calendar calendar = Calendar.getInstance();
            @SuppressLint("SimpleDateFormat") SimpleDateFormat std = new SimpleDateFormat("HH:mm:ss\nE, dd MMM yyyy");
            String date = std.format(calendar.getTime());
            tCurrTime.setText(date);
            tCurrTime.setVisibility(View.VISIBLE);

        }else {
            Toast.makeText(this, "No Internet🤔", Toast.LENGTH_LONG).show();
        }
        hideKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        try {
            inputMethodManager.hideSoftInputFromWindow(Objects.requireNonNull(getCurrentFocus()).getWindowToken(), 0);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    private boolean isInternetConnected(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.isActiveNetworkMetered();
    }
}